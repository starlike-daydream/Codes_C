#include<bits/stdc++.h>
#define ll long long;
#define IOS ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
using namespace std;

int main(){
    // string s,w1,w2,w="";
    // int len = 0;
    // getline(cin,s);本题有\r和\n，不能用getline
    // cin>>w1>>w2;
    // for (int i = 0; i < s.size(); i++){
    //     if(s[i] == ' '){
    //         if(len == w1.size())
    //                 cout<<w2<<' ';
    //         else
    //             cout<<w<<' ';
    //         w="";
    //     }else{
    //         w += s[i];
    //         if(s[i] == w1[len])
    //             len++;
    //         else
    //             len=0;
    //     }
    //     if(i == s.size() - 1){
    //         if(len == w1.size())
    //                 cout<<w2<<' ';
    //         else
    //             cout<<w<<' ';
    //         // w="";
    //     }
    // }
    return 0;
}