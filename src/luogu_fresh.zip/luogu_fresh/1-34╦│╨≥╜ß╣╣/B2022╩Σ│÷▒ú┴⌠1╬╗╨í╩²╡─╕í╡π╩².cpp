#include<bits/stdc++.h>
using namespace std;

int main(){
    double num;
    cin>>num;
    cout<<fixed<<setprecision(12)<<num;
    return 0;
}