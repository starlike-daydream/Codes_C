#include<bits/stdc++.h>
using namespace std;

int main(){
    float num;
    cin>>num;
    cout<<fixed<<setprecision(3)<<num;
    return 0;
}