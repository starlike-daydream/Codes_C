#include<bits/stdc++.h>
using namespace std;

int main(){
    int a,b,c;
    cin>>a>>b>>c;
    cout<<(a + b) * c;//对！星号*是相乘运算
    return 0;//好习惯
}