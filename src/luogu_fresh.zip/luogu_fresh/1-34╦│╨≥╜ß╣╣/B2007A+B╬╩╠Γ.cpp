#include<bits/stdc++.h>
using namespace std;

int main(){
    int A,B;
    cin>>A>>B;
    cout<<A + B;//也可以直接输出表达式，嗯，没错，这是相加运算
    return 0;//好习惯
}