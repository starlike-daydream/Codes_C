#include<bits/stdc++.h>
using namespace std;

int main(){
    int c;
    cin>>c;//获取ASCII码
    cout<<(char)c;//输出对应字符
    return 0; 
}