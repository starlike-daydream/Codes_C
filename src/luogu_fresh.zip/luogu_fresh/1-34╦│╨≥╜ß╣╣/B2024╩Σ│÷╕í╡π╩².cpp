#include<bits/stdc++.h>
using namespace std;

int main(){
    double f;
    cin>>f;
    printf("%f\n%.5f\n%e\n%g",f,f,f,f);
    return 0;
}