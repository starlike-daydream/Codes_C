#include <bits/stdc++.h>
using namespace std;

int main(){
    double a, b;
    cin >> a >> b;
    cout << a - int(a / b) * b << endl;
    return 0;
}