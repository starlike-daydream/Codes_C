#include<iostream>
#define ll long long 
using namespace std;
//都说了是测试程序，想从0开始还是跳了吧（会B2007就够写本题了）
int main(){
    ll a,b;
    cin>>a>>b;
    cout<<a+b;
    return 0;
}