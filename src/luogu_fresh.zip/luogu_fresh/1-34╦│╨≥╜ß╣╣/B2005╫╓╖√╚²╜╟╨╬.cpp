#include<iostream>
#define ll long long 
using namespace std;

int main(){
    s c;//声明字符串变量，与C不同，这是C++特有的数据类型
    cin>>c;
    cout<<"  "<<c<<endl<<" "<<c<<c<<c<<endl<<c<<c<<c<<c<<c;//暴力输出，结束
    return 0;//好习惯
}