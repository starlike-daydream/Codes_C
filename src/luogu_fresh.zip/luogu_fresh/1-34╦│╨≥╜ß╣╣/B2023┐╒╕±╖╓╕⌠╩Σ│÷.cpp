#include<bits/stdc++.h>
using namespace std;

int main(){
    char c;
    int i;
    float f;
    double d;
    cin>>c>>i>>f>>d;
    cout<<c<<" "<<i<<" "<<fixed<<setprecision(6)<<f<<" "<<fixed<<setprecision(6)<<d;
    return 0;
}