#include<bits/stdc++.h>
using namespace std;

int main(){
    int a,b;
    cin>>a>>b;
    cout<<a / b<<" "<<a % b;//这是求余数（取模）运算！  5 / 2 = 2 ...1(余数)
    return 0;//好习惯
}