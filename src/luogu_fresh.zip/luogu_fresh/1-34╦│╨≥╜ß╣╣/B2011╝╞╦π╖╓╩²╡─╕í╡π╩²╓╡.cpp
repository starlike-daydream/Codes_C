#include<bits/stdc++.h>
using namespace std;

int main(){
    double a,b;
    cin>>a>>b;
    cout<<fixed<<setprecision(9)<<a/b;
    return 0;//好习惯
}