#include<bits/stdc++.h>
using namespace std;

int main(){
    int num;
    cin>>num;//获取整形变量
    cout<<(bool)num;//转化为布尔值变量输出
    return 0; 
}

//c语言中，除了0以外的数字都被看做为真（1），而0的布尔值是0（假），c语言中的布尔值用1/0表示真/假