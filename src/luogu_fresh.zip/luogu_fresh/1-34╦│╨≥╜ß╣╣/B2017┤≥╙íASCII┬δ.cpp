#include<bits/stdc++.h>
using namespace std;

int main(){
    char c;
    cin>>c;//获取输入的字符
    cout<<(int)c;//将其强制转化为整数输出
    return 0;
}

//字符和整数可以相互转换，这是因为字符在计算机中以数的形式储存（对应ASCII码）